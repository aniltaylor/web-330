/*
============================================
Title: Assignment 3
Author: Professor Krasso
Date: 10 June 2022
Modified By: <ANITA TAYLOR>
Description: This program demonstrates the
use of JavaScript types, values, and
and variables in an application.
===========================================
*/

// Create and export product class with name and price parameters.
export class Product {
  constructor(name, price) {
    this.name = name;
    this.price = price;
  }
}