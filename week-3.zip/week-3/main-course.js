/*
============================================
Title: Assignment 3
Author: Professor Krasso
Date: 10 June 2022
Modified By: <ANITA TAYLOR>
Description: This program demonstrates the
use of JavaScript types, values, and
and variables in an application.
===========================================
*/
// Import product class from product.js
import { Product } from "./product";

// Create MainCourse class/export module.
export class MainCourse extends Product {
  constructor(name, price) {
    super(name, price);
  }
}